package model;

public enum MoveResult {
    BACKDO,
    DO,
    GAE,
    GEOL,
    YUT,
    MO,
    STACK,
    CAPTURE,
}