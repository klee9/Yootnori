package model;

public enum GameState {
    READY,
    RUNNING,
    ENDED;
}