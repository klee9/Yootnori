[실행 방법]
yootnori.jar 더블 클릭, 혹은 터미널에서 프로젝트 디렉토리로 이동 후 아래 커맨드 입력

java -jar yootnori.jar